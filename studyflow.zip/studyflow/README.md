# StudyFlow - Student Task Management System

A full-stack mini project that helps students plan assignments, lab records and exams.
Users register, log in and manage their own tasks with priorities, subjects and due dates,
while a dashboard shows pending, completed, overdue and high-priority counts.

**Tech stack:** Node.js, Express, SQLite (better-sqlite3), JWT authentication, bcrypt password hashing,
and a vanilla HTML / CSS / JavaScript front end.

**Authors:** Prajan Raam M, Nidhish V - B.Tech Information Technology, St. Joseph's Institute of Technology

## Features

- Register and log in with a secure, hashed password and a JWT session token (2-hour expiry)
- Create, view, edit, complete and delete tasks
- Search by title or subject, and filter by status or priority
- Dashboard statistics: total, pending, completed, overdue and high-priority tasks
- Per-user data isolation: one user can never read or change another user's tasks
- Input validation on both API and form, with clear error messages
- REST API with 12 automated tests

## Getting started

Requirements: Node.js 18 or newer.

```bash
git clone <your-repo-url>
cd studyflow
npm install
cp .env.example .env      # optional: set JWT_SECRET (Windows: copy .env.example .env)
npm start
```

Open http://localhost:3000, create an account and start adding tasks.

Environment variables (all optional): `PORT` (default 3000), `JWT_SECRET` (set a long random value
for anything beyond local use), `DB_PATH` (default `./studyflow.db`).
Note: the app reads these from the environment; to load a `.env` file automatically, run
`node --env-file=.env server.js` (Node 20.6+).

## Run the tests

```bash
npm test
```

## Project structure

```
studyflow/
  server.js            Express app, static files, error handling
  db.js                SQLite connection and table creation
  middleware/auth.js   JWT signing and verification middleware
  routes/auth.js       Register and login endpoints
  routes/tasks.js      Task CRUD, filters and statistics
  public/              Front end (index.html, style.css, app.js)
  test/api.test.js     Automated API tests (node:test)
  docs/screenshots/    Screenshots used in the project report
```

## API reference

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/health` | No | Health check |
| POST | `/api/auth/register` | No | Create account `{name, email, password}` |
| POST | `/api/auth/login` | No | Log in `{email, password}`, returns token |
| GET | `/api/tasks?status=&priority=&q=` | Yes | List own tasks with optional filters |
| GET | `/api/tasks/stats/summary` | Yes | Dashboard counts |
| POST | `/api/tasks` | Yes | Create task `{title, subject, priority, due_date, description}` |
| PUT | `/api/tasks/:id` | Yes | Update task fields |
| PATCH | `/api/tasks/:id/toggle` | Yes | Switch between pending and done |
| DELETE | `/api/tasks/:id` | Yes | Delete task |

Send the token as `Authorization: Bearer <token>`.

## Screenshots

| Login | Dashboard |
|-------|-----------|
| ![Login](docs/screenshots/01-login.png) | ![Dashboard](docs/screenshots/03-dashboard.png) |

## Future enhancements

Email or SMS reminders, a calendar view, shared study groups, file attachments, and deployment to a cloud host.

## License

MIT
