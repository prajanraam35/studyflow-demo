const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const PRIORITIES = ['low', 'medium', 'high'];
const STATUSES = ['pending', 'done'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// Validates and normalises task input. Returns { error } or { value }.
function validate(body, partial = false) {
  const out = {};

  if (!partial || body.title !== undefined) {
    const title = String(body.title || '').trim();
    if (!title) return { error: 'Title is required' };
    if (title.length > 120) return { error: 'Title must be 120 characters or fewer' };
    out.title = title;
  }
  if (body.description !== undefined) out.description = String(body.description).trim().slice(0, 1000);
  if (body.subject !== undefined) out.subject = String(body.subject).trim().slice(0, 60);
  if (body.priority !== undefined) {
    if (!PRIORITIES.includes(body.priority)) return { error: 'Priority must be low, medium or high' };
    out.priority = body.priority;
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) return { error: 'Status must be pending or done' };
    out.status = body.status;
  }
  if (body.due_date !== undefined) {
    if (body.due_date === null || body.due_date === '') {
      out.due_date = null;
    } else if (!DATE_RE.test(body.due_date) || Number.isNaN(Date.parse(body.due_date))) {
      return { error: 'Due date must be in YYYY-MM-DD format' };
    } else {
      out.due_date = body.due_date;
    }
  }
  return { value: out };
}

// GET /api/tasks?status=&priority=&q=
router.get('/', (req, res) => {
  const where = ['user_id = ?'];
  const params = [req.user.id];

  if (STATUSES.includes(req.query.status)) { where.push('status = ?'); params.push(req.query.status); }
  if (PRIORITIES.includes(req.query.priority)) { where.push('priority = ?'); params.push(req.query.priority); }
  if (req.query.q) {
    where.push('(title LIKE ? OR subject LIKE ?)');
    const like = `%${String(req.query.q).trim()}%`;
    params.push(like, like);
  }

  const rows = db
    .prepare(
      `SELECT * FROM tasks WHERE ${where.join(' AND ')}
       ORDER BY status = 'done', due_date IS NULL, due_date, id DESC`
    )
    .all(...params);
  res.json(rows);
});

// GET /api/tasks/stats/summary  (must be declared before /:id)
router.get('/stats/summary', (req, res) => {
  const row = db
    .prepare(
      `SELECT
         COUNT(*) AS total,
         COALESCE(SUM(status = 'done'), 0) AS done,
         COALESCE(SUM(status = 'pending'), 0) AS pending,
         COALESCE(SUM(status = 'pending' AND due_date IS NOT NULL
                      AND due_date < date('now', 'localtime')), 0) AS overdue,
         COALESCE(SUM(status = 'pending' AND priority = 'high'), 0) AS high_priority
       FROM tasks WHERE user_id = ?`
    )
    .get(req.user.id);
  res.json(row);
});

router.post('/', (req, res) => {
  const { error, value } = validate(req.body);
  if (error) return res.status(400).json({ error });

  const info = db
    .prepare(
      `INSERT INTO tasks (user_id, title, description, subject, priority, due_date)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(
      req.user.id,
      value.title,
      value.description || '',
      value.subject || '',
      value.priority || 'medium',
      value.due_date || null
    );
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(task);
});

router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'Task not found' });

  const { error, value } = validate(req.body, true);
  if (error) return res.status(400).json({ error });

  const merged = { ...existing, ...value };
  db.prepare(
    `UPDATE tasks SET title = ?, description = ?, subject = ?, priority = ?, status = ?, due_date = ?
     WHERE id = ? AND user_id = ?`
  ).run(merged.title, merged.description, merged.subject, merged.priority, merged.status, merged.due_date, existing.id, req.user.id);

  res.json(db.prepare('SELECT * FROM tasks WHERE id = ?').get(existing.id));
});

router.patch('/:id/toggle', (req, res) => {
  const existing = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'Task not found' });

  const next = existing.status === 'done' ? 'pending' : 'done';
  db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run(next, existing.id);
  res.json({ ...existing, status: next });
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Task not found' });
  res.status(204).end();
});

module.exports = router;
