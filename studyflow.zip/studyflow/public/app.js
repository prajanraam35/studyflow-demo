(() => {
  const $ = (sel) => document.querySelector(sel);

  let token = localStorage.getItem('sf_token');
  let user = JSON.parse(localStorage.getItem('sf_user') || 'null');
  let mode = 'login';        // 'login' | 'register'
  let editingId = null;      // id of the task being edited, or null when adding
  let tasks = [];

  // ---------- helpers ----------
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch('/api' + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = res.status === 204 ? null : await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && token) logout();
      throw new Error((data && data.error) || 'Request failed');
    }
    return data;
  }

  // ---------- auth ----------
  function showView() {
    $('#auth-view').hidden = !!token;
    $('#app-view').hidden = !token;
    if (token) {
      $('#user-name').textContent = user ? user.name : '';
      refresh();
    }
  }

  function setMode(next) {
    mode = next;
    $('#tab-login').classList.toggle('active', mode === 'login');
    $('#tab-register').classList.toggle('active', mode === 'register');
    $('#name-field').hidden = mode !== 'register';
    $('#auth-submit').textContent = mode === 'login' ? 'Login' : 'Create account';
    $('#password').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
    $('#auth-error').textContent = '';
  }

  function logout() {
    token = null; user = null;
    localStorage.removeItem('sf_token');
    localStorage.removeItem('sf_user');
    showView();
  }

  $('#tab-login').addEventListener('click', () => setMode('login'));
  $('#tab-register').addEventListener('click', () => setMode('register'));
  $('#logout').addEventListener('click', logout);

  $('#auth-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#auth-error').textContent = '';
    try {
      const payload = { email: $('#email').value, password: $('#password').value };
      if (mode === 'register') payload.name = $('#name').value;
      const data = await api(`/auth/${mode}`, { method: 'POST', body: payload });
      token = data.token; user = data.user;
      localStorage.setItem('sf_token', token);
      localStorage.setItem('sf_user', JSON.stringify(user));
      $('#auth-form').reset();
      showView();
    } catch (err) {
      $('#auth-error').textContent = err.message;
    }
  });

  // ---------- tasks ----------
  async function refresh() {
    const params = new URLSearchParams();
    if ($('#f-q').value.trim()) params.set('q', $('#f-q').value.trim());
    if ($('#f-status').value) params.set('status', $('#f-status').value);
    if ($('#f-priority').value) params.set('priority', $('#f-priority').value);
    try {
      const [list, stats] = await Promise.all([api('/tasks?' + params), api('/tasks/stats/summary')]);
      tasks = list;
      renderStats(stats);
      renderTasks();
    } catch (err) {
      if (token) $('#form-error').textContent = err.message;
    }
  }

  function renderStats(s) {
    const items = [
      ['Total tasks', s.total, ''], ['Pending', s.pending, ''], ['Completed', s.done, ''],
      ['Overdue', s.overdue, s.overdue ? 'warn' : ''], ['High priority', s.high_priority, ''],
    ];
    $('#stats').innerHTML = items.map(([label, n, cls]) => `<div class="stat ${cls}"><b>${n}</b><span>${label}</span></div>`).join('');
  }

  function renderTasks() {
    $('#empty').hidden = tasks.length > 0;
    $('#task-list').innerHTML = tasks.map((t) => {
      const overdue = t.status === 'pending' && t.due_date && t.due_date < today();
      return `
        <li class="task ${t.status}" data-id="${t.id}">
          <input type="checkbox" ${t.status === 'done' ? 'checked' : ''} aria-label="Mark complete" />
          <div class="task-main">
            <div class="task-title">${esc(t.title)}</div>
            ${t.description ? `<div class="task-desc">${esc(t.description)}</div>` : ''}
            <div class="meta">
              <span class="badge ${t.priority}">${t.priority}</span>
              ${t.subject ? `<span class="badge">${esc(t.subject)}</span>` : ''}
              ${t.due_date ? `<span class="muted">Due ${esc(t.due_date)}</span>` : ''}
              ${overdue ? '<span class="badge overdue">Overdue</span>' : ''}
            </div>
          </div>
          <div class="task-actions">
            <button class="icon-btn" data-act="edit" type="button">Edit</button>
            <button class="icon-btn danger" data-act="delete" type="button">Delete</button>
          </div>
        </li>`;
    }).join('');
  }

  function resetForm() {
    editingId = null;
    $('#task-form').reset();
    $('#form-title').textContent = 'Add a task';
    $('#t-submit').textContent = 'Add task';
    $('#t-cancel').hidden = true;
    $('#form-error').textContent = '';
  }

  $('#task-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#form-error').textContent = '';
    const body = {
      title: $('#t-title').value,
      subject: $('#t-subject').value,
      priority: $('#t-priority').value,
      due_date: $('#t-due').value || null,
      description: $('#t-desc').value,
    };
    try {
      if (editingId) await api(`/tasks/${editingId}`, { method: 'PUT', body });
      else await api('/tasks', { method: 'POST', body });
      resetForm();
      refresh();
    } catch (err) {
      $('#form-error').textContent = err.message;
    }
  });

  $('#t-cancel').addEventListener('click', resetForm);

  $('#task-list').addEventListener('click', async (e) => {
    const li = e.target.closest('.task');
    if (!li) return;
    const id = li.dataset.id;
    const act = e.target.dataset.act;
    try {
      if (e.target.type === 'checkbox') {
        await api(`/tasks/${id}/toggle`, { method: 'PATCH' });
        refresh();
      } else if (act === 'delete') {
        if (confirm('Delete this task?')) { await api(`/tasks/${id}`, { method: 'DELETE' }); refresh(); }
      } else if (act === 'edit') {
        const t = tasks.find((x) => String(x.id) === id);
        editingId = t.id;
        $('#t-title').value = t.title;
        $('#t-subject').value = t.subject;
        $('#t-priority').value = t.priority;
        $('#t-due').value = t.due_date || '';
        $('#t-desc').value = t.description;
        $('#form-title').textContent = 'Edit task';
        $('#t-submit').textContent = 'Update task';
        $('#t-cancel').hidden = false;
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      $('#form-error').textContent = err.message;
    }
  });

  let timer;
  $('#f-q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(refresh, 250); });
  $('#f-status').addEventListener('change', refresh);
  $('#f-priority').addEventListener('change', refresh);

  setMode('login');
  showView();
})();
