process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'test-secret';

const test = require('node:test');
const assert = require('node:assert/strict');
const app = require('../server');

let server, base;
test.before(() => new Promise((resolve) => {
  server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; resolve(); });
}));
test.after(() => new Promise((resolve) => server.close(resolve)));

async function call(method, path, { token, body } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, data: text ? JSON.parse(text) : null };
}

const alice = { name: 'Alice', email: 'alice@example.com', password: 'secret123' };
const bob = { name: 'Bob', email: 'bob@example.com', password: 'secret456' };
let aliceToken, bobToken, taskId;

test('health endpoint responds', async () => {
  const r = await call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.data.status, 'ok');
});

test('register creates a user and returns a token', async () => {
  const r = await call('POST', '/api/auth/register', { body: alice });
  assert.equal(r.status, 201);
  assert.ok(r.data.token);
  aliceToken = r.data.token;
  bobToken = (await call('POST', '/api/auth/register', { body: bob })).data.token;
});

test('register rejects duplicate email and weak input', async () => {
  assert.equal((await call('POST', '/api/auth/register', { body: alice })).status, 409);
  assert.equal((await call('POST', '/api/auth/register', { body: { ...bob, email: 'bad' } })).status, 400);
  assert.equal((await call('POST', '/api/auth/register', { body: { ...bob, email: 'x@y.com', password: '123' } })).status, 400);
});

test('login succeeds with correct password and fails with wrong one', async () => {
  const ok = await call('POST', '/api/auth/login', { body: { email: alice.email, password: alice.password } });
  assert.equal(ok.status, 200);
  const bad = await call('POST', '/api/auth/login', { body: { email: alice.email, password: 'wrong' } });
  assert.equal(bad.status, 401);
});

test('task routes require authentication', async () => {
  assert.equal((await call('GET', '/api/tasks')).status, 401);
  assert.equal((await call('GET', '/api/tasks', { token: 'garbage' })).status, 401);
});

test('create task validates input', async () => {
  assert.equal((await call('POST', '/api/tasks', { token: aliceToken, body: {} })).status, 400);
  assert.equal((await call('POST', '/api/tasks', { token: aliceToken, body: { title: 'x', priority: 'urgent' } })).status, 400);
  assert.equal((await call('POST', '/api/tasks', { token: aliceToken, body: { title: 'x', due_date: '31/12/2026' } })).status, 400);
});

test('create, list and filter tasks', async () => {
  const a = await call('POST', '/api/tasks', { token: aliceToken, body: { title: 'DBMS record', subject: 'DBMS', priority: 'high', due_date: '2000-01-01' } });
  assert.equal(a.status, 201);
  taskId = a.data.id;
  await call('POST', '/api/tasks', { token: aliceToken, body: { title: 'Read networks notes', subject: 'CN', priority: 'low' } });

  const all = await call('GET', '/api/tasks', { token: aliceToken });
  assert.equal(all.data.length, 2);
  const high = await call('GET', '/api/tasks?priority=high', { token: aliceToken });
  assert.equal(high.data.length, 1);
  const search = await call('GET', '/api/tasks?q=networks', { token: aliceToken });
  assert.equal(search.data[0].subject, 'CN');
});

test('update and toggle a task', async () => {
  const up = await call('PUT', `/api/tasks/${taskId}`, { token: aliceToken, body: { title: 'DBMS record (final)' } });
  assert.equal(up.data.title, 'DBMS record (final)');
  assert.equal(up.data.priority, 'high');
  const tg = await call('PATCH', `/api/tasks/${taskId}/toggle`, { token: aliceToken });
  assert.equal(tg.data.status, 'done');
  const back = await call('PATCH', `/api/tasks/${taskId}/toggle`, { token: aliceToken });
  assert.equal(back.data.status, 'pending');
});

test('summary statistics count overdue and high priority tasks', async () => {
  const r = await call('GET', '/api/tasks/stats/summary', { token: aliceToken });
  assert.deepEqual(r.data, { total: 2, done: 0, pending: 2, overdue: 1, high_priority: 1 });
});

test('users cannot see or change each other\'s tasks', async () => {
  assert.equal((await call('GET', '/api/tasks', { token: bobToken })).data.length, 0);
  assert.equal((await call('PUT', `/api/tasks/${taskId}`, { token: bobToken, body: { title: 'hacked' } })).status, 404);
  assert.equal((await call('DELETE', `/api/tasks/${taskId}`, { token: bobToken })).status, 404);
});

test('delete removes a task', async () => {
  assert.equal((await call('DELETE', `/api/tasks/${taskId}`, { token: aliceToken })).status, 204);
  assert.equal((await call('GET', '/api/tasks', { token: aliceToken })).data.length, 1);
});

test('unknown API route returns JSON 404', async () => {
  const r = await call('GET', '/api/nothing');
  assert.equal(r.status, 404);
});
